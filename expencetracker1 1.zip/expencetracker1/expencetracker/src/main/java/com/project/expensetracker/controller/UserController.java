package com.project.expensetracker.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.expensetracker.service.UserService;
import com.project.expensetracker.vo.LoginVo;
import com.project.expensetracker.vo.RegistrationRequestVo;
import com.project.expensetracker.vo.RegistrationResponseVo;

@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	private UserService userService;

	@PostMapping("/registerUser")
	public RegistrationResponseVo createNewUser(@RequestBody RegistrationRequestVo requestVo) {
		return userService.createNewUser(requestVo);
	}
	@PostMapping("/userLogin")
	public    RegistrationResponseVo userLogin(@RequestBody LoginVo loginVo) {
		return userService.userLogin(loginVo);
	}
}

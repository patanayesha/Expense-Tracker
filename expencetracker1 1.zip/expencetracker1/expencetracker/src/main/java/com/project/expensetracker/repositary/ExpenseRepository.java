package com.project.expensetracker.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.expensetracker.entity.ExpenseEntity;

@Repository
public interface ExpenseRepository extends JpaRepository<ExpenseEntity,Long> {
	
	@Query(nativeQuery=true,value="select  * from expense_details where userUniqueExpenseId=:uniqueId where month(date)=:month")
	List<ExpenseEntity> getExpensesListById(@Param("uniqueId") Long uniqueId,@Param("month") String month);
	
	@Query(nativeQuery=true,value="select  * from expense_details where userUniqueExpenseId=:uniqueId where id=:id")
	ExpenseEntity getRecordByuserUniqueIdAndId(@Param("uniqueId") Long uniqueId,@Param("id") Long id);
	

}

package com.project.expensetracker.vo;

public class ExpenseResponseVo {
	private String SuccessResponse;
	private String FailureResponse;

	public String getSuccessResponse() {
		return SuccessResponse;
	}

	public void setSuccessResponse(String successResponse) {
		SuccessResponse = successResponse;
	}

	public String getFailureResponse() {
		return FailureResponse;
	}

	public void setFailureResponse(String failureResponse) {
		FailureResponse = failureResponse;
	}

}

package com.project.expensetracker.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.expensetracker.entity.ExpenseEntity;
import com.project.expensetracker.repositary.ExpenseRepository;
import com.project.expensetracker.vo.ExpenseRequestVo;
import com.project.expensetracker.vo.ExpenseResponseVo;

@Service
public class ExpenseService {
	@Autowired
	private ExpenseRepository expenseRepository;

	public ExpenseResponseVo createNewExpense(ExpenseRequestVo requestVo) {
		ExpenseResponseVo response = new ExpenseResponseVo();
		if (requestVo == null) {
			response.setFailureResponse("Please Enter Required Fields");
		}
		ExpenseEntity expenseEntity = new ExpenseEntity();
		expenseEntity.setIncome(requestVo.getIncome());
		expenseEntity.setSourceOfIncome(requestVo.getSourceOfIncome());
		expenseEntity.setExpence(requestVo.getExpence());
		expenseEntity.setPurposeOfExpence(requestVo.getPurposeOfExpence());
		expenseRepository.save(expenseEntity);
		response.setSuccessResponse("ok");
		return response;

	}

	public List<ExpenseRequestVo> getAllExpensesOfUserByMonth(String month, Long userUniqueId) {
		List<ExpenseRequestVo> expensesList = new ArrayList<>();
		List<ExpenseEntity> userExpensesList = expenseRepository.getExpensesListById(userUniqueId, month);
		if (userExpensesList == null) {
			return new ArrayList<>();

		}
		expensesList = userExpensesList.stream().map(elm -> {

			ExpenseRequestVo vo = new ExpenseRequestVo();
			vo.setDate(elm.getDate());
			vo.setExpence(elm.getExpence());
			vo.setId(elm.getId());
			vo.setUserUiqueId(elm.getUserUniqueExpenseId());
			vo.setPurposeOfExpence(elm.getPurposeOfExpence());
			vo.setSourceOfIncome(elm.getSourceOfIncome());

			return vo;
		}).collect(Collectors.toList());

		return expensesList;
	}

	public ExpenseResponseVo editUserExpensesByIdAndUserUniqueId(Long id, Long userUniqueId,ExpenseRequestVo  expenseVo) {
		ExpenseResponseVo response =new ExpenseResponseVo();
		if(userUniqueId==null ||id==null ) {
			 response.setFailureResponse("User Id And expenseId are Null.Please Enter Valid Details. ");
			 return response;
		}
		
		ExpenseEntity existingExpenseEntity=expenseRepository.getRecordByuserUniqueIdAndId(id,userUniqueId);
		
		if(existingExpenseEntity==null) {
			 response.setFailureResponse("Failed To Load the Existing User Expense.Please Enter Valid Details. ");
			 return response;
		}
		if(expenseVo.getDate()!=null) {
			existingExpenseEntity.setDate(expenseVo.getDate());
		}
		if(expenseVo.getExpence()!=null) {
			existingExpenseEntity.setExpence(expenseVo.getExpence());
		}
		if(expenseVo.getPurposeOfExpence()!=null) {
			existingExpenseEntity.setPurposeOfExpence(expenseVo.getPurposeOfExpence());
		}
		if(expenseVo.getSourceOfIncome()!=null) {
			existingExpenseEntity.setSourceOfIncome(expenseVo.getSourceOfIncome());
		}
		if(expenseVo.getIncome()!=null) {
			existingExpenseEntity.setIncome(expenseVo.getIncome());
		}
		
		expenseRepository.save(existingExpenseEntity);
		response.setSuccessResponse("User Expenses Update Successfull");
		return response;
		
	}
	public ExpenseResponseVo deleteUserExpensesByIdAndUserUniqueId(Long id, Long userUniqueId) {
		ExpenseResponseVo response =new ExpenseResponseVo();
		if(userUniqueId==null ||id==null ) {
			 response.setFailureResponse("User Id And expenseId are Null.Please Enter Valid Details. ");
			 return response;
		}
		
		ExpenseEntity existingExpenseEntity=expenseRepository.getRecordByuserUniqueIdAndId(id,userUniqueId);
		if(existingExpenseEntity==null) {
			 response.setFailureResponse("Failed to Load User Expenses Details.Please Enter Valid Details. ");
			 return response;
		}
		expenseRepository.deleteById(id);
		response.setSuccessResponse("Expense Deleted Successful");
		return response;
	}
	

}

package com.project.expensetracker.vo;

public class RegistrationResponseVo {
	private String SuccessResponce;
	private String FailureResponce;
	public String getSuccessResponce() {
		return SuccessResponce;
	}
	public void setSuccessResponce(String successResponce) {
		SuccessResponce = successResponce;
	}
	public String getFailureResponce() {
		return FailureResponce;
	}
	public void setFailureResponce(String failureResponce) {
		FailureResponce = failureResponce;
	}
	

}

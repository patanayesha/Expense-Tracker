package com.project.expensetracker.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import com.project.expensetracker.entity.UserEntity;
import com.project.expensetracker.repositary.UserRepository;
import com.project.expensetracker.vo.LoginVo;
import com.project.expensetracker.vo.RegistrationRequestVo;
import com.project.expensetracker.vo.RegistrationResponseVo;


@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	public RegistrationResponseVo createNewUser(RegistrationRequestVo requestVo) {
		RegistrationResponseVo response = new RegistrationResponseVo();
		if (requestVo == null) {
			response.setFailureResponce("Please Enter Required Fields");

		}
		UserEntity userEntity = new UserEntity();
		userEntity.setFullName(requestVo.getFullName());
		userEntity.setMobileNumber(requestVo.getMobileNumber());
		userEntity.setEmail(requestVo.getEmail());
		userEntity.setPassword(requestVo.getPassword());
		userRepository.save(userEntity);
		response.setSuccessResponce("Successfully Registered");
		return response;

	}

	public RegistrationResponseVo userLogin(LoginVo loginVo) {

		RegistrationResponseVo response = new RegistrationResponseVo();
		if (loginVo == null) {
			response.setFailureResponce("Please Entert the Required Fields");
		}
		UserEntity existinUserEntity = userRepository.findByEmail(loginVo.getEmail());
		if (existinUserEntity == null) {
			response.setFailureResponce("Email Not Found");
		}

		if (existinUserEntity.getPassword().equals(loginVo.getPassword())) {
			response.setSuccessResponce("User Login Successfull");
		}
		response.setFailureResponce("Please Enter Valid Password ");
		
		
		

		return response;
	}
}

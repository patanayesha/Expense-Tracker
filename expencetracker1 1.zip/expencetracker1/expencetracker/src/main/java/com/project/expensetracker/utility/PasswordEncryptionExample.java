package com.project.expensetracker.utility;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordEncryptionExample {
	 public static void main(String[] args) {
	        String plaintextPassword = "user-entered-password";

	       
	        String hashedPassword = BCrypt.hashpw(plaintextPassword, BCrypt.gensalt());

	     
	        System.out.println("Hashed Password: " + hashedPassword);
	    }
	}



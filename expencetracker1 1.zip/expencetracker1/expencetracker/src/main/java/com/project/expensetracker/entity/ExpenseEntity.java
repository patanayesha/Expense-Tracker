package com.project.expensetracker.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "expense_details")

public class ExpenseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String income;
	private String sourceOfIncome;
	private String expence;
	private Date date;
	private String purposeOfExpence;
	private Long userUniqueExpenseId;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getSourceOfIncome() {
		return sourceOfIncome;
	}

	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}

	public String getExpence() {
		return expence;
	}

	public void setExpence(String expence) {
		this.expence = expence;
	}

	public String getPurposeOfExpence() {
		return purposeOfExpence;
	}

	public void setPurposeOfExpence(String purposeOfExpence) {
		this.purposeOfExpence = purposeOfExpence;
	}

	public Long getUserUniqueExpenseId() {
		return userUniqueExpenseId;
	}

	public void setUserUniqueExpenseId(Long userUniqueExpenseId) {
		this.userUniqueExpenseId = userUniqueExpenseId;
	}

}

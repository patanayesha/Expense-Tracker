package com.project.expensetracker.utility;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordVerificationExample {
	   public static void main(String[] args) {
	        String savedHashedPassword = "";

	        String enteredPassword = "user-entered-password";

	     
	        if (BCrypt.checkpw(enteredPassword, savedHashedPassword)) {
	            System.out.println("Password Match!");
	        } else {
	            System.out.println("Incorrect Password!");
	        }
	    }
	}


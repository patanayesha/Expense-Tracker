package com.project.expensetracker.vo;

import java.util.Date;

public class ExpenseRequestVo {
	private String income;
	private String sourceOfIncome;
	private String expence;
	private Date date;
	private String purposeOfExpence;
	private Long id;
	private Long userUiqueId;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserUiqueId() {
		return userUiqueId;
	}

	public void setUserUiqueId(Long userUiqueId) {
		this.userUiqueId = userUiqueId;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getSourceOfIncome() {
		return sourceOfIncome;
	}

	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}

	public String getExpence() {
		return expence;
	}

	public void setExpence(String expence) {
		this.expence = expence;
	}

	public String getPurposeOfExpence() {
		return purposeOfExpence;
	}

	public void setPurposeOfExpence(String purposeOfExpence) {
		this.purposeOfExpence = purposeOfExpence;
	}

}
